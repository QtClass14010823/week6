typedef int (*callback)(int, int);

void insertion_sort(int *array, int n, callback comparison);
