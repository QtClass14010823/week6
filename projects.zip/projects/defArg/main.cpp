#include <iostream>

void f(int a, int b, int c = 1);     // valid
void f(int a, int b = 1, int c);     // valid, add another default
void f(int a = 1, int b, int c);     // valid, add another default
void f(int a, int b, int c)
{
    std::cout << a << ", " << b << ", " << c << std::endl;
}

int main()
{
    f();
    f(8);
    f(8, 9);
    f(8, 9, 10);

    return 0;
}
